This is the developer guide for Nektar++.
